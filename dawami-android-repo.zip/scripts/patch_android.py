"""يُشغَّل بعد `npx cap add android`: الأذونات، الأيقونات، شاشة البداية، ألوان الشريط."""
import pathlib, re, shutil

main = pathlib.Path("android/app/src/main")
res = main / "res"

# 1) الأذونات
m = main / "AndroidManifest.xml"
s = m.read_text(encoding="utf-8")
perms = ["POST_NOTIFICATIONS", "SCHEDULE_EXACT_ALARM", "USE_EXACT_ALARM",
         "RECEIVE_BOOT_COMPLETED", "VIBRATE", "WAKE_LOCK"]
add = "".join('    <uses-permission android:name="android.permission.%s"/>\n' % p
              for p in perms if "android.permission.%s" % p not in s)
s = s.replace("</manifest>", add + "</manifest>")
if "supportsRtl" not in s:
    s = s.replace("<application", '<application android:supportsRtl="true"', 1)
m.write_text(s, encoding="utf-8")

# 2) الأيقونات وشاشة البداية (حذف splash.png الافتراضية ثم نسخ مواردنا)
for p in res.rglob("splash.png"):
    p.unlink()
shutil.copytree("resources/res", res, dirs_exist_ok=True)

# 3) ألوان شريط الحالة وخلفية شاشة البداية
st = res / "values" / "styles.xml"
if st.exists():
    t = st.read_text(encoding="utf-8")
    t = re.sub(r'(<style name="AppTheme\.NoActionBar"[^>]*>)',
               r'\1\n        <item name="android:statusBarColor">#0A1F4D</item>'
               r'\n        <item name="android:navigationBarColor">#071A40</item>', t, 1)
    if "Theme.SplashScreen" in t:
        t = re.sub(r'(<style name="AppTheme\.NoActionBarLaunch"[^>]*>)',
                   r'\1\n        <item name="windowSplashScreenBackground">#071A40</item>', t, 1)
    st.write_text(t, encoding="utf-8")
print("patch_android: done")
